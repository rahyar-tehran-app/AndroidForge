package com.rahyartehran.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.util.Locale;

public class MainActivity extends Activity implements LocationListener {
    private static final int LOCATION_PERMISSION = 41;
    private LocationManager locationManager;
    private TextToSpeech tts;
    private TextView speedView, limitView, messageView, destinationView;
    private EditText limitEdit;
    private int speedLimit = 60;
    private float currentSpeed = 0;
    private long lastWarning = 0;
    private boolean overLimit = false;
    private Uri incomingUri;
    private String incomingText = "";
    private String destination = "هنوز مقصدی از اسنپ دریافت نشده";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        handleIntent(getIntent());
        tts = new TextToSpeech(this, result -> {
            if (result == TextToSpeech.SUCCESS) tts.setLanguage(new Locale("fa", "IR"));
        });
        locationManager = (LocationManager)getSystemService(LOCATION_SERVICE);
        render();
        requestGps();
    }
    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent); setIntent(intent); handleIntent(intent);
        if (destinationView != null) destinationView.setText(destination);
    }
    private void handleIntent(Intent intent) {
        if (intent == null) return;
        Uri data = intent.getData();
        if (Intent.ACTION_VIEW.equals(intent.getAction()) && data != null) {
            incomingUri = data; incomingText = "";
            String scheme = data.getScheme();
            if ("google.navigation".equalsIgnoreCase(scheme)) {
                String q = data.getQueryParameter("q");
                if (q == null) q = data.getSchemeSpecificPart();
                destination = "مقصد دریافتی: " + (q == null ? data.toString() : q);
            } else if ("geo".equalsIgnoreCase(scheme)) {
                String query = data.getQuery();
                destination = "درخواست مکان دریافت شد: " + (query == null ? data.getSchemeSpecificPart() : query);
            } else destination = "درخواست مسیر دریافت شد";
        } else if (Intent.ACTION_SEND.equals(intent.getAction())) {
            CharSequence shared = intent.getCharSequenceExtra(Intent.EXTRA_TEXT);
            if (shared != null) { incomingText = shared.toString(); incomingUri = null; destination = "متن مقصد دریافت شد: " + incomingText; }
        }
    }
    private void render() {
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(28,26,28,22); root.setBackgroundColor(Color.rgb(17,27,36)); root.setGravity(Gravity.CENTER_HORIZONTAL);
        TextView title = new TextView(this); title.setText("رهیار تهران"); title.setTextSize(29); title.setTextColor(Color.WHITE); title.setGravity(Gravity.CENTER); root.addView(title, lp());
        TextView sub = new TextView(this); sub.setText("مسیریاب آزمایشی رانندگان"); sub.setTextSize(14); sub.setTextColor(Color.rgb(180,198,211)); sub.setGravity(Gravity.CENTER); root.addView(sub, lp());
        destinationView = new TextView(this); destinationView.setText(destination); destinationView.setTextSize(15); destinationView.setTextColor(Color.rgb(128,230,165)); destinationView.setGravity(Gravity.CENTER); destinationView.setPadding(0,22,0,12); root.addView(destinationView, lp());
        speedView = new TextView(this); speedView.setText("سرعت فعلی\n-- km/h"); speedView.setTextSize(30); speedView.setTextColor(Color.WHITE); speedView.setGravity(Gravity.CENTER); speedView.setPadding(0,18,0,18); root.addView(speedView, lp());
        limitView = new TextView(this); limitView.setText("سرعت مجاز تنظیم‌شده: ۶۰ km/h"); limitView.setTextSize(18); limitView.setTextColor(Color.rgb(128,230,165)); limitView.setGravity(Gravity.CENTER); root.addView(limitView, lp());
        limitEdit = new EditText(this); limitEdit.setSingleLine(true); limitEdit.setText("60"); limitEdit.setHint("سرعت مجاز این مسیر به km/h"); limitEdit.setTextColor(Color.WHITE); limitEdit.setHintTextColor(Color.LTGRAY); root.addView(limitEdit, lp());
        Button apply = button("ثبت سرعت مجاز"); apply.setOnClickListener(v -> { try { int n=Integer.parseInt(limitEdit.getText().toString().trim()); if(n<10||n>160) throw new NumberFormatException(); speedLimit=n; limitView.setText("سرعت مجاز تنظیم‌شده: "+n+" km/h"); overLimit=false; checkSpeed(); } catch(Exception e) { Toast.makeText(this,"عددی بین ۱۰ تا ۱۶۰ وارد کن",Toast.LENGTH_SHORT).show(); } }); root.addView(apply,lp());
        messageView = new TextView(this); messageView.setText("برای نمایش سرعت، اجازه مکان‌یابی بده."); messageView.setTextSize(15); messageView.setTextColor(Color.WHITE); messageView.setGravity(Gravity.CENTER); messageView.setPadding(0,12,0,12); root.addView(messageView,lp());
        Button open = button("باز کردن مقصد دریافتی"); open.setOnClickListener(v -> openRoute()); root.addView(open,lp());
        Button map = button("باز کردن نقشه عمومی"); map.setOnClickListener(v -> { try { startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("google.navigation:q=Tehran&mode=d"))); } catch(Exception e) { startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("https://www.google.com/maps/dir/?api=1&destination=Tehran&travelmode=driving"))); } }); root.addView(map,lp());
        TextView note = new TextView(this); note.setText("نسخه آزمایشی: مقصد فقط در صورت ارسال قالب استاندارد از اسنپ دریافت می‌شود. سرعت مجاز فعلاً دستی است؛ نقشه داخلی و ترافیک زنده هنوز اضافه نشده‌اند. به تابلوهای واقعی توجه کن."); note.setTextSize(12); note.setTextColor(Color.rgb(255,207,120)); note.setPadding(2,16,2,0); root.addView(note,lp());
        setContentView(root);
    }
    private LinearLayout.LayoutParams lp(){ return new LinearLayout.LayoutParams(-1,-2); }
    private Button button(String s){ Button b=new Button(this); b.setText(s); return b; }
    private void openRoute(){
        try {
            if(incomingUri!=null){ Intent i=new Intent(Intent.ACTION_VIEW,incomingUri); i.setPackage("com.google.android.apps.maps"); try { startActivity(i); } catch(Exception e){ i.setPackage(null); startActivity(i); } }
            else if(!incomingText.trim().isEmpty()){ Uri u=Uri.parse("https://www.google.com/maps/dir/?api=1&destination="+Uri.encode(incomingText.trim())+"&travelmode=driving"); startActivity(new Intent(Intent.ACTION_VIEW,u)); }
            else Toast.makeText(this,"هنوز مقصدی دریافت نشده است",Toast.LENGTH_LONG).show();
        } catch(Exception e){ Toast.makeText(this,"باز کردن مقصد ممکن نشد؛ قالب ارسالی ممکن است پشتیبانی نشود",Toast.LENGTH_LONG).show(); }
    }
    private void requestGps(){ if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},LOCATION_PERMISSION); else startGps(); }
    private void startGps(){ try { if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED){ locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,1000,0,this); messageView.setText("GPS فعال است؛ در انتظار موقعیت..."); } } catch(SecurityException e){ messageView.setText("دسترسی GPS فعال نیست"); } }
    @Override public void onRequestPermissionsResult(int code,String[] perms,int[] results){ super.onRequestPermissionsResult(code,perms,results); if(code==LOCATION_PERMISSION&&results.length>0&&results[0]==PackageManager.PERMISSION_GRANTED) startGps(); else messageView.setText("برای نمایش سرعت، اجازه مکان‌یابی لازم است"); }
    @Override public void onLocationChanged(Location loc){ if(loc.hasSpeed()) currentSpeed=loc.getSpeed()*3.6f; speedView.setText(String.format(Locale.US,"سرعت فعلی\n%.0f km/h",currentSpeed)); checkSpeed(); }
    private void checkSpeed(){ if(messageView==null)return; if(currentSpeed>speedLimit+2){ messageView.setText("⚠ سرعت بالاتر از حد تنظیم‌شده است"); messageView.setTextColor(Color.rgb(255,110,110)); long now=System.currentTimeMillis(); if(!overLimit||now-lastWarning>12000){ if(tts!=null) tts.speak("هشدار، سرعت شما از سرعت مجاز بیشتر است",TextToSpeech.QUEUE_FLUSH,null,"speed-warning"); overLimit=true; lastWarning=now; } } else { messageView.setText("سرعت در محدوده تنظیم‌شده است"); messageView.setTextColor(Color.rgb(128,230,165)); overLimit=false; } }
    @Override public void onProviderEnabled(String provider){}
    @Override public void onProviderDisabled(String provider){ if(messageView!=null)messageView.setText("GPS خاموش است؛ مکان‌یابی را روشن کن"); }
    @Override public void onStatusChanged(String provider,int status,Bundle extras){}
    @Override protected void onDestroy(){ super.onDestroy(); if(locationManager!=null)locationManager.removeUpdates(this); if(tts!=null){tts.stop();tts.shutdown();} }
}
